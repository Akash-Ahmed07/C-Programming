#include<stdio.h>

int main (){

     int n;
     scanf("%d",&n);
     int hash=1;
     int space = n-1;
     
     for(int i = 1;i<=n;i++){

        for(int j =1; j<=space; j++){
            printf(" ");
        }
         for(int k =1; k<=hash; k++){
            printf("#");
        }
        printf("\n");
        hash +=4;
        space--;

     }


     for(int i = n;i>=1;i--){

        for(int j =1; j<=space; j++){
            printf(" ");
        }
         for(int k =1; k<=hash; k++){
            printf("#");
        }
        printf("\n");
        hash -=3;
        space++;

     }
    return 0;
}