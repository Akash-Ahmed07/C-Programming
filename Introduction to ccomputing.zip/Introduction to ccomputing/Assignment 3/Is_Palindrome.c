#include<stdio.h>
#include<string.h>
int is_palindrome(char s[]){
    int leng = strlen(s);
    for(int i=0 ; i<leng;i++){
        if(s[i]!= s[leng - i -1]){
            return 0;

        }

    }

 return 1;
} 

int main (){

     char s[1001];
     scanf("%s",s);
    
     int ans = is_palindrome(s); 
     if(ans == 0){
        printf("Not Palindrome");
     }

     else if (ans == 1){
        printf("Palindrome");
     }

    return 0;
}