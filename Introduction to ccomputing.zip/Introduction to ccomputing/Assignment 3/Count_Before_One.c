#include <stdio.h>

int count_before_one(int ar[], int n)
{
    int count = 0;

    for (int i = 0; i < n; i++)
    {
        if (ar[i] == 1)
        {
            break;
        }
        count++;
    }
    return count;
}

int main()
{

    int a;
    scanf("%d", &a);
    int ar[a];
    for (int i = 0; i < a; i++)
    {
        scanf("%d", &ar[i]);
    }
    int value = count_before_one(ar, a);
    printf("%d", value);

    return 0;
}