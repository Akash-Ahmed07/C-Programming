#include <stdio.h>

int is_palindrome(char str[])
{
    int leg = strlen(str);
    for (int i = 0; i < leg / 2; i++)
    {
        if (str[i] != str[leg - i - 1])
        {
            return 0;
        }
    }
    return 1;
}

int main()
{

    char str[1001];
    scanf("%s", str);

    int ans = is_palindrome(str);

    if (ans == 1)
        printf("Palindrome");
    else
        printf("Not Palindrome");
    return 0;
}