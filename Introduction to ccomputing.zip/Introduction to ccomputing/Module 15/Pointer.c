#include<stdio.h>

int main (){

     int x =10;
     printf("%d\n",x);
     printf("%p\n",&x);
     int* ptr;
     ptr = &x;
     printf("%p\n",ptr);//pointer value adress
     printf("%p\n",&ptr);//pointer adress print
     printf("%d\n",*ptr);// what value store in pointer 
    return 0;
}