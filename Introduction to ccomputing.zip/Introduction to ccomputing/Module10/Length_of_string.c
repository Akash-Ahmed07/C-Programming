#include<stdio.h>
#include<string.h>

int main (){

     char sr[101];
     scanf("%s",&sr);
     
   //   int count=0;
   //   for(int i =0; sr[i] !='\0'; i++){   // '\0' = null character
   //      count++;
   //   }
    // printf("%d",count);

    //lengtg shortcut
    int size = strlen(sr);
    printf("%d",size);
    return 0;
}