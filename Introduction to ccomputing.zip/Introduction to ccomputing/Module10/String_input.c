#include<stdio.h>

int main (){

     char sr[10];
     scanf("%s",&sr);
     printf("%s",sr);
    return 0;
}