#include<stdio.h>


int main (){

     char sr[50];
    fgets(sr,19,stdin); //gets(sr); single line //fgets double line with enter button
     
     printf("%s",sr);
    return 0;
}