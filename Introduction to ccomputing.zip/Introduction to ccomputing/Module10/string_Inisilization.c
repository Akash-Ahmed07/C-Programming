#include<stdio.h>

int main (){

     //char s[6] = {'A','K','A','S','H'};
     char s[20] = "Sabbir Ahmed Akash";
     printf("%s",s);
    return 0;
}