#include <stdio.h>

int main()
{

    int t;
    scanf("%d", &t);
    for (int i = 0; i < t; i++)
    {
       long long int n, x, y, z;
        scanf("%lld %lld %lld %lld", &n, &x, &y, &z);

        if (x <= 0 || y <= 0 || z <= 0) {
            printf("-1\n");
            continue;
        }



      long long int  miss = x*y*z ;
       long long int div = n / miss;
        long long int ans = miss * div;
        if (ans == n)
        {
           printf("%lld\n", div);
        }
        else
        {
            printf("-1\n");
        }
        
         

        
    }
    return 0;
}