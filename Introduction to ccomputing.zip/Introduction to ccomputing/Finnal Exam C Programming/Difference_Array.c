#include <stdio.h>

int main()
{
    int x;
    scanf("%d", &x);
    for (int z = 0; z < x; z++)
    {
        int n;
        scanf("%d", &n);
        int ar[n];
        int b[n];
        for (int i = 0; i < n; i++)
        {
            scanf("%d", &ar[i]);
            b[i] = ar[i];
        }

        for (int i = 0; i < n - 1; i++)
        {
            for (int j = i + 1; j < n; j++)
            {
                if (ar[i] > ar[j])
                {
                    int tem = ar[i];
                    ar[i] = ar[j];
                    ar[j] = tem;
                }
            }
        }
        int c[n];
        for (int i = 0; i < n; i++)
        {
            c[i] = b[i] - ar[i];

            if (c[i] < 0)
            {
                c[i] = -c[i];
            }
            printf("%d ", c[i]);
        }
        printf("\n");
    }
    return 0;
}