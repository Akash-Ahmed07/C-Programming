#include <stdio.h>

int main()
{
    int r, c;
    scanf("%d %d", &r, &c);
    int ar[r][c];
    for (int i = 0; i < r; i++)
    {
        for (int j = 0; j < c; j++)
        {
            scanf("%d", &ar[i][j]);
        }
    }
    int total= r*c;
    int count =0 ;
     for (int i = 0; i < r; i++)
    {
        for (int j = 0; j < c; j++)
        {
            if(ar[i][j]==0){
                count++;
            }
        }
    }
      


    if(total==count){
        printf("Zero Matrix\n");
    }
     
    else{
        printf("this is not Zero matrix\n");
    }
}
