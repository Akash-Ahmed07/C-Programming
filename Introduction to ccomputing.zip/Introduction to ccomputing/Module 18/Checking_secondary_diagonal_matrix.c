#include <stdio.h>

int main()
{
    int r, c;
    scanf("%d %d", &r, &c);
    int ar[r][c];
    for (int i = 0; i < r; i++)
    {
        for (int j = 0; j < c; j++)
        {
            scanf("%d", &ar[i][j]);
        }
    }
    int is_diagonal = 1;

    if (r == c)
    {
        for (int i = 0; i < r; i++)
        {
            for (int j = 0; j < c; j++)
            {
                if (i + j == r - 1)
                {
                    // we are in primary diagonal
                }
                else if (ar[i][j] != 0)
                {
                    is_diagonal = 5;
                    printf("This is not secondary diagonal matrix\n");
                }
            }
        }
        if (is_diagonal == 1)
        {
            printf("This is  secondary diagonal matrix\n");
        }
    }

    else
    {
        printf("This is not secondary diagonal matrix\n");
    }
}