#include<stdio.h>

int main (){

     int r,c;
     scanf("%d %d",&r , &c);
     int ar [r][c];
     for(int i =0; i<r; i++){
        for(int j=0; j<c; j++){
            scanf("%d",&ar[i][j]);

        }
     }
     int col_to_print;
     scanf("%d",&col_to_print);
     for(int i =0; i<r;i++){
        printf("%d ",ar[i][col_to_print]);
     }
    return 0;
}