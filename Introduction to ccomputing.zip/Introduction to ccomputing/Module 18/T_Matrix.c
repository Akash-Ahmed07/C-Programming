#include <stdio.h>
#include <stdlib.h>

int main()
{

    int rc;
    scanf("%d", &rc);
    int matrix[rc][rc];
    for (int i = 0; i < rc; i++)
    {
        for (int j = 0; j < rc; j++)
        {
            scanf("%d", &matrix[i][j]);
        }
    }

    int sum = 0;
    int d = 0;

    for (int i = 0; i < rc; i++)
    {

        sum = sum + matrix[i][i];
    }

    for (int i = 0; i < rc; i++)
    {

        d = d + matrix[i][rc - 1 - i];
    }

    int finnal = abs(sum - d);

    printf("%d\n", finnal);
    return 0;
}