
        for (int i = 0; i < r; i++)