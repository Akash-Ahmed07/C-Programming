#include<stdio.h>

int main (){

     int x;
     scanf("%d\n",&x);
     int even = 0, odd = 0, pos = 0, neg = 0;
     for (int  i = 1; i <= x; i++)
     {
        int n;
        scanf("%d",&n);
        if(n % 2 == 0){
          even++;
        }
        else {
          odd++;
        }

         if(n > 0){
          pos++;
        }
        else if(n < 0){
            neg++;
        }
     }
     printf("Even: %d\n",even);
     printf("Odd: %d\n",odd);
     printf("Positive: %d\n",pos);
     printf("Negative: %d\n",neg);
     
    return 0;
}