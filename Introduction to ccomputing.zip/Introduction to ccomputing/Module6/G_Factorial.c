#include <stdio.h>

int main()
{

    int n;

    scanf("%d", &n);

    for (int i = 1; i <= n; i++)
    {
        int x;
        long long int fact = 1;
        scanf("%d", &x);

        for (int j = 1; j <= x; j++)
        {

            fact *= j;
        }
        printf("%lld\n", fact);
    }

    return 0;
}