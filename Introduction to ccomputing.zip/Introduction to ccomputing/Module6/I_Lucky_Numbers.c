#include <stdio.h>

int main() {
    int x;
    scanf("%d", &x);

    int mod = x % 10;
    int div = x / 10;

    if ((mod != 0 && div % mod == 0) || (div != 0 && mod % div == 0))
        printf("YES\n");
    else
        printf("NO\n");

    return 0;
}
