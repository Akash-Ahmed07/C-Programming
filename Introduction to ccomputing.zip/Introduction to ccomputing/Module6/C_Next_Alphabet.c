#include <stdio.h>

int main()
{

    char ch;
    scanf("%c", &ch);

    if (ch >= 'a' && ch < 'z')
    {
        char sum = ch + 1;
        printf("%c", sum);
    }
    else if (ch == 'z')
    {
        char digit = ch - 25;
        printf("%c", digit);
    }

    return 0;
}