#include<stdio.h>

int x = 10; 

int sum(){
     printf("sum function -> %d\n",x);
    
}

int main (){

     printf("main -> %d\n",x);
     sum();
    return 0;
}