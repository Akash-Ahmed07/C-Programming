#include<stdio.h>

//return_type function_name(perametter){
// return;
// }