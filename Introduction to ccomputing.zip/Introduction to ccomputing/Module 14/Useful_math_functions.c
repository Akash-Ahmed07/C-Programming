#include <stdio.h>
#include <math.h>

int main()
{
    int ans = ceil(5.6);
    int result = floor(5.6);
    int roun = round(5.6);
    int sq = sqrt(16);
    double sq_1 = sqrt(20);
    int ans1 = pow(3, 2);
    int ans2 = abs(-10);
    printf("%d %d %d %d %llf %d %d", ans, result, roun, sq, sq_1, ans1, ans2);

    return 0;
}