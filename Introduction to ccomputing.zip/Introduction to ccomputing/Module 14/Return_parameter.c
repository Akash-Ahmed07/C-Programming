#include<stdio.h>

//return_type function_name(perametter){
// return;
// }

int sum(int num1, int num2){

   int ans = num1 + num2;
    return ans;
}

int main (){
      
    int a,b;
    scanf("%d %d",&a,&b);
    int value= sum(a,b);
    printf("%d",value);
     
    return 0;
}