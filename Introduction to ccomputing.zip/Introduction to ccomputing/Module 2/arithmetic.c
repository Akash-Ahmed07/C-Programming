#include<stdio.h>
int main (){
    int a = 10;
    int b = 5;
    int sum = a + b;
    int sub = a - b;
    int mult = a * b;
    float div = (float) a / b;
    printf("the sum is: %d\n",sum);
    printf("the sub is: %d\n",sub);
    printf("the mult is: %d\n",mult);
    printf("the div is: %.2f\n",div);

    return 0;

}