#include<stdio.h>
int main (){
   int tk;
   scanf("%d",&tk);
   if(tk >= 100){
    printf("Burger khabo");
   }
   else{
    printf("Burger khabo na");
   }

    return 0;

}