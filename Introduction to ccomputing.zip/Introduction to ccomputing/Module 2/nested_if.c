#include <stdio.h>
int main()
{
    int tk;
    scanf("%d", &tk);
    if (tk >= 5000)
    {   
         printf("Cox's Bazar jabo\n");

        if (tk >=10000){
            printf("sant martin Jabo");
        }

        else{
            printf("fetorth chole ashbo");
        }
    }
    else
    {
        printf("Khutaw jabo na");
    }

    return 0;
}