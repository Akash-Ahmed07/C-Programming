#include<stdio.h>
int main (){
    int a = 12;
    int b = 5;
    int rem = a % b;
    printf("%d",rem);

    return 0;

}