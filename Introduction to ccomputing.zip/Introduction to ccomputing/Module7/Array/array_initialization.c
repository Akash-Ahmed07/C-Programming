#include<stdio.h>

int main (){

    //  int ar[5] = {20,10,30,40,50}; OR
     int ar[] = {10,20,30,40,50};
     for(int i = 0; i<5; i++){
        printf("%d ",ar[i]);
     }
    return 0;
}