#include <stdio.h>

int main()
{

    int n, pos =0, odd=0;
    scanf("%d", &n);
    int arr[n];

    for (int i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);

        //  if (arr[i] > 0)
        // {
        //     pos += arr[i];
            
        // }

    }

    for (int i = 0; i < n; i++)
    {
        if (arr[i] > 0)
        {
            pos += arr[i];
        }
    }

    for (int i = 0; i < n; i++)
    {
        if (arr[i] < 0)
        {
            odd += arr[i];
        }
    }

    printf("%d %d",pos,odd);

    return 0;
}