#include<stdio.h>

int main (){

     int ar [5];
     ar[3] = 200;
     ar[2] = 50;
     ar[1] = 30;
     printf("%d, %d, %d",ar[1], ar[2],ar[3]);

    return 0;
}