#include <stdio.h>

int main()
{
    int n;
    scanf("%d", &n);
    int ar[n];
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &ar[i]);
    }
    int m;
    scanf("%d", &m);
    int br[m];
    for (int i = 0; i < m; i++)
    {
        scanf("%d", &br[i]);
    }

    int cr[n + m];
    for (int i = 0; i < n; i++)
    {
       cr[i] = ar[i];
    }
 for (int i = 0; i < m; i++)
    {
       cr[n+i] = br[i];
    }
    for (int i = 0; i < n+m; i++)
    {
        printf("%d ", cr[i]);
    }

    return 0;
}