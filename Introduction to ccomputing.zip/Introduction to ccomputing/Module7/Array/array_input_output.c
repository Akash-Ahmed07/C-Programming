#include<stdio.h>

int main (){
    int ar[5];


    // scanf("%d %d %d %d %d %d %d %d %d %d",&ar[0],&ar[1],&ar[2],&ar[3],&ar[4],&ar[5],&ar[6],&ar[7],&ar[8],&ar[9]);
    // printf("%d %d %d %d %d %d %d %d %d %d",ar[0],ar[1],ar[2],ar[3],ar[4],ar[5],ar[6],ar[7],ar[8],ar[9]);

     for(int i =0;i<5 ; i++){
        scanf("%d",&ar[i]);
        printf(" %d ",ar[i]);
     }
    return 0;
}