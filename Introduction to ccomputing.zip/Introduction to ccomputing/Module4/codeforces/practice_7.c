#include <stdio.h>

int main()
{

    int x, y, z;
    scanf("%d %d %d", &x, &y, &z);
    if (x < y && x < z)
    {

        if (y > x && y > z)
        {
        }
        printf("%d", x);
        printf(" %d", y);
    }

    else if (y < x && y < z)
    {

        if (z > x && z > y)
        {
        }
        printf("%d", y);
        printf(" %d", z);
    }

    else if (z < y && z < x)
    {

        if (x > y && x > z)
        {
        }
        printf("%d", z);
        printf("%d", x);
    }
    return 0;
}