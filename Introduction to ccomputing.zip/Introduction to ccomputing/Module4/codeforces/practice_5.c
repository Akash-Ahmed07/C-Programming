#include<stdio.h>

int main (){
 
     char a;
     
     scanf("%c",&a);
     char upper = a  + 32;
     char lower = a - 32;

     if( a>= upper){
        printf("%c", lower);
     }
     else{
        printf("%c",upper);
     }
     

    return 0;
}