#include<stdio.h>

int main (){
    // Unique Problem (Find First Digit): https://codeforces.com/group/MWSDmqGsZm/contest/219158/problem/J
    
     int a;
     scanf("%d",&a);
     int digit = a / 1000;
     if (digit % 2 == 0 )
     {
        printf("EVEN");
     }
     else{
        printf("ODD");
     }
     
    return 0;
}