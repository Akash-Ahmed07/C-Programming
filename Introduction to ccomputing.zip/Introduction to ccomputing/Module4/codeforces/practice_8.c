#include <stdio.h>

int main()
{
    
    int x, y, z;
    scanf("%d %d %d", &x, &y, &z);

    //Minimum
    if (x <= y && x <= z)
    {

        printf("%d ", x);
    }

    else if (y <= x && y <= z)
    {

        printf("%d ", y);
    }

    else if (z <= y && z <= x)
    {

        printf("%d ", z);
    }

    //Maximum
    if (x >= y && x >= z)
    {

        printf("%d", x);
    }

    else if (y >= x && y >= z)
    {

        printf("%d", y);
    }

    else if (z >= x && z >= y)
    {

        printf("%d", z);
    }



       return 0;
}