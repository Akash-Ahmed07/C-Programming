#include<stdio.h>

int main (){
    // Unique Problem (Find last Digit)
    
     int a;
     scanf("%d",&a);
     int digit = a % 10;
     if (digit % 2 == 0 )
     {
        printf("EVEN");
     }
     else{
        printf("ODD");
     }
     
    return 0;
}