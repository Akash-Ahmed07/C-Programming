#include<stdio.h>

int main(){
   long long int a =  10000000000000;
   

   printf("%lld",a); 
   
    return 0;
}