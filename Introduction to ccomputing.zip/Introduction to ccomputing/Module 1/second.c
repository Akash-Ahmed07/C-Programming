#include<stdio.h>
#include<stdbool.h>
int main(){
    bool b;
    b = false;
    printf("%d",b);
    
    return 0;
}