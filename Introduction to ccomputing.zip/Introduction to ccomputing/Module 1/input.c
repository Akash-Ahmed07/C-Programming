#include<stdio.h>
int main(){
    int a;
    float b;
    char c;
    scanf("%d %f %cc", &a,&b,&c);
    // scanf("%d", &a);
    // scanf("%f", &b);
    // scanf("%c", &c);
    printf("%d, %.2f, %c",a,b,c);
    return 0;
}