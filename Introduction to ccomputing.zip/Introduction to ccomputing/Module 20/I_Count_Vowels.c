#include <stdio.h>
int rec(char sr[], int i)
{
    if (sr[i] == '\0')
    {
        return 0;
    }
     int count =  rec(sr, i + 1);
      if(sr[i]=='a' || sr[i]=='e' || sr[i]=='i' || sr[i]=='o' || sr[i]=='u' ||
      sr[i]=='A' || sr[i]=='E' || sr[i]=='I' || sr[i]=='O' || sr[i]=='U'){
        return count+1;
      }
      else{
             return count ;
      }
   
}
int main()
{

    char sr[201];
    fgets(sr, 201, stdin);
    int count = rec(sr, 0);
    printf("%d", count);

    return 0;
}