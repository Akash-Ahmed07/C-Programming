#include<stdio.h>

int main (){

     char a[21], b[21];
        scanf("%s %s", a, b);
        int valu = strcmp(a,b);
        if(valu<0){
            printf("%s\n",a);

        }
        else{
         printf("%s\n", b);
        }
        
    return 0;
}