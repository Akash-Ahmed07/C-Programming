#include <stdio.h>
#include <string.h>

int main()
{

    char a[101], b[101];
    scanf("%s %s", &a, &b);
   int valu = strcmp(a,b);
    if(valu < 0){
         printf("A smaller than");
    }
    else if(valu > 0){
         printf("B smaller than");
    }
    else if (valu == 0)
    {
        printf("Equal");
    }
          


    return 0;
}