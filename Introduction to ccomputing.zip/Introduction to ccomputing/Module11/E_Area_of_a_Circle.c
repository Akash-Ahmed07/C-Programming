#include<stdio.h>
int main()
{
    double x;
    scanf("%lf",&x);
    double r = 3.141592653;
    double area=r*(x*x);
    printf("%.9lf",area);
    return 0;
 
}