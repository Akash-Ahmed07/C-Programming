#include<stdio.h>
void mello(){
    printf("Mello\n");
}
void gelo(){
    
    printf("Gelo\n");
    mello();
     
}
void hello(){
    printf("Hello\n");
    gelo();
}
int main (){

     printf("Hello, World!\n");
     hello();
    return 0;
}