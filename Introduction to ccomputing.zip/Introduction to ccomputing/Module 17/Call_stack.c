#include<stdio.h>
void mello(){
    printf(" Mello");
}
void gelo(){
    printf(" Gelo");
    mello();
}
void hello(){
    printf("Hello");
    gelo();
}
int main (){

     printf("Hello, World!\n");
     hello();
    return 0;
}