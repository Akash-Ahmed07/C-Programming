#include<stdio.h>
void  hello(int i, int n){
    if(i>n){
        return;
    }
    
     
     printf("%d\n",i);
     hello(i+1,n);
}

int main (){

     int n;
     int i =1;
     scanf("%d",&n);
     hello(i,n);
    return 0;
}