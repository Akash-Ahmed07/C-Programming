#include <stdio.h>
void hello(int i)
{
    if (i == 0)//base case
    {
        return;
    }
    printf("%d\n", i);
    hello(i - 1);
}

int main()
{

    // int i =1;
    hello(10);
    return 0;
}