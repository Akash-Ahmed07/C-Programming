#include<stdio.h>
void hello(int i,int n){
    if(n>i){
        return;
    }
    printf("I love Recursion\n");
    hello(i,n+1);
}

int main (){

     int i;
     int n = 1;
     
        scanf("%d",&i);
        
        hello(i,n);

    return 0;
}