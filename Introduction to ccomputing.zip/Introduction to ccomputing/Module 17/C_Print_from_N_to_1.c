#include<stdio.h>
void  hello(int i, int n){
    if(i>n){
        return;
    }
    
     hello(i+1,n);
    // printf("%d ",i);
    if(i == 1)
        printf("%d", i);     
    else
        printf("%d ", i);   
      
}

int main (){

     int n;
     int i =1;
     scanf("%d",&n);
     hello(i,n);
    return 0;
}