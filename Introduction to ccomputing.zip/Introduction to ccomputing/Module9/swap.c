#include<stdio.h>

int main (){

   
     int temp, b = 20, a=10;
    
     temp = a;
     a = b;
      b = temp;
      printf("A = %d\nB = %d",a,b);
    return 0;
}