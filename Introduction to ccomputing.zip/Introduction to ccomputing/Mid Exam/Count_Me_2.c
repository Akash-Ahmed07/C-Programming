#include <stdio.h>
#include <string.h>

int main()
{

    char ch[100001];
    scanf("%s", ch);
    char xh;

    int count = 0;
    for (int i = 0; ch[i] != '\0'; i++)
    {
        xh = ch[i];

        if (xh >= 'a' && xh <= 'z')
        {
            if (xh == 'a' || xh == 'e' || xh == 'i' || xh == 'o' || xh == 'u')

            {
                continue;
            }
            count++;
        }
        // xh = strlen(xh);
        //  printf("%c ", xh);
    }

    // int count = strlen(xh);
    printf("%d", count);
    return 0;
}
