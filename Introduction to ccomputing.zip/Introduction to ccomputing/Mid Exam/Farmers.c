
#include <stdio.h>

int main()
{

    int n;
    scanf("%d", &n);
    // int far,day,far2;
    // int total =0;
    for (int i = 1; i <= n; i++)
    {
        int far, day, far2;
        int total = 0;
        scanf("%d %d %d", &far, &far2, &day);
        total = (far * day / (far + far2)) - day;
        printf("%d\n", -total);
    }
    // for (int i = 1; i <= n; i++)
    // {
    //     total = (far * day) - (far2 * (30 - day));
    //     printf("%d\n", total);
    // }

    return 0;
}