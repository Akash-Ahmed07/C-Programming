#include <stdio.h>

int main()
{

    char c[10001];
    scanf("%s", c);
    // int count = 0;
    for (char j = 'a'; j <= 'z'; j++)
    { 
           int count = 0;
        for (int i = 0; c[i] != '\0'; i++)
        {

            //    count++;
            if (c[i] == j)
            {
                count++;
               
            }
            
            //   count++;
        }
        if(count>0){
            printf("%c - %d\n", j, count);
            }
    }

    return 0;
}
