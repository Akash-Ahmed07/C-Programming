#include <stdio.h>
#include <string.h>

int main()
{
    int x;
    scanf("%d", &x);
    char ch[100001];

    char xh;

    // int count = 0;
    // int small = 0;
    // int digit = 0;
    for (int i = 1; i <= x; i++)
    {

        scanf("%s", ch);
        int count = 0;
        int small = 0;
        int digit = 0;
        for (int i = 0; ch[i] != '\0'; i++)
        {
            xh = ch[i];
            if (xh >= 'A' && xh <= 'Z')
            {

                count++;
            }
            else if (xh >= 'a' && xh <= 'z')
            {

                small++;
            }

            else if (xh >= '0' && xh <= '9')
            {

                digit++;
            }

            // printf("%d %d %d\n", count, small, digit);
        }
        printf("%d %d %d\n", count, small, digit);
    }

    // for (int i = 1; i <= x; i++)
    // {
    //     printf("%d %d %d\n", count, small, digit);
    // }

    // int count = strlen(xh);
    //   printf("%d %d %d\n", count, small, digit);
    // printf("%d %d %d\n", count, small, digit);
    return 0;
}