#include<stdio.h>

int main () {

    for(int i = 1; i <= 20; i++) {

        printf("%d I am Sorry\n", i);
    }

    return 0;
}
