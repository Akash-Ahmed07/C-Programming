#include<stdio.h>

int main () {
    for(int i = 2; i <= 64; i=i*2) {
        printf("%d\n", i);
    }
    return 0;
}
